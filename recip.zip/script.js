/* =========================================
   BASE DE DADOS DOS PROJETOS
   ========================================= */
const projectsData = [
    // Participativa
    { id: "part-01", nome: "NPS (Relacional, Transacional, Competitiva e do Canal)", desafio: "Participativa", descricao: "Avaliação da satisfação dos associados em diferentes interações.", detalhes: "O Net Promoter Score é aplicado em múltiplas frentes para medir a experiência do associado." },
    { id: "part-02", nome: "Coordenação da Jornada do Associado", desafio: "Participativa", descricao: "Gestão integrada da experiência do associado.", detalhes: "Garante que todas as etapas da jornada sejam coordenadas." },
    { id: "part-03", nome: "Plataforma de Relacionamento", desafio: "Participativa", descricao: "Canal digital para interação contínua.", detalhes: "Ferramenta que centraliza informações e serviços." },
    { id: "part-04", nome: "Matriz de Comunicação", desafio: "Participativa", descricao: "Estrutura para organizar canais e mensagens.", detalhes: "Define fluxos e periodicidade das comunicações." },
    { id: "part-05", nome: "Rituais de Comunicação", desafio: "Participativa", descricao: "Encontros regulares para alinhamento.", detalhes: "Práticas formais que reforçam governança e cultura." },
    { id: "part-06", nome: "Check-in dos Conteúdos", desafio: "Participativa", descricao: "Revisão periódica de informações.", detalhes: "Processo para validar e atualizar conteúdos de negócios." },
    { id: "part-07", nome: "Relatório de Assembleias", desafio: "Participativa", descricao: "Documento com decisões e resultados.", detalhes: "Consolidado que assegura transparência e engajamento." },
    { id: "part-08", nome: "Podcast Sicredi Conexão", desafio: "Participativa", descricao: "Conteúdo em áudio para engajamento.", detalhes: "Canal informativo que aproxima associados e colaboradores." },
    { id: "part-09", nome: "Notícias e Conteúdos", desafio: "Participativa", descricao: "Divulgação de informações estratégicas.", detalhes: "Publicações periódicas que reforçam transparência." },
    { id: "part-10", nome: "Momentos Presenciais", desafio: "Participativa", descricao: "Encontros para fortalecer vínculos.", detalhes: "Eventos que promovem interação e escuta ativa." },
    { id: "part-11", nome: "Site com Acessibilidade", desafio: "Participativa", descricao: "Inclusão digital para todos.", detalhes: "Recursos que garantem navegação adaptada." },
    { id: "part-12", nome: "Conteúdos com Legendas/Libras", desafio: "Participativa", descricao: "Materiais adaptados para inclusão.", detalhes: "Vídeos com legendas e interpretação em Libras." },
    { id: "part-13", nome: "Crédito à Acessibilidade", desafio: "Participativa", descricao: "Linha de crédito inclusiva.", detalhes: "Condições especiais para apoiar investimentos em acessibilidade." },
    { id: "part-14", nome: "Cartilha Atendimento Inclusivo", desafio: "Participativa", descricao: "Guia para atendimento acessível.", detalhes: "Material que orienta sobre práticas inclusivas." },
    { id: "part-15", nome: "Agências com Acessibilidade", desafio: "Participativa", descricao: "Infraestrutura inclusiva.", detalhes: "Adequação física das unidades conforme legislação." },
    { id: "part-16", nome: "Cartão em Braile", desafio: "Participativa", descricao: "Produto adaptado.", detalhes: "Cartão com informações em Braile para deficientes visuais." },
    { id: "part-17", nome: "Cursos sobre Acessibilidade", desafio: "Participativa", descricao: "Capacitação para inclusão.", detalhes: "Treinamentos para atendimento inclusivo." },
    { id: "part-18", nome: "Cooperativas Escolares", desafio: "Participativa", descricao: "Educação cooperativista para jovens.", detalhes: "Programa que incentiva cooperativas em escolas." },
    { id: "part-19", nome: "Programa Líder Jovem", desafio: "Participativa", descricao: "Formação de lideranças jovens.", detalhes: "Desenvolvimento de habilidades de liderança e engajamento." },
    
    // Colaborativa
    { id: "colab-01", nome: "Capacitação Empresa Rural", desafio: "Colaborativa", descricao: "Formação em gestão rural.", detalhes: "Parceria com Auriverde para capacitar produtores." },
    { id: "colab-02", nome: "Formação Agro em Foco", desafio: "Colaborativa", descricao: "Curso sobre tendências no agro.", detalhes: "Iniciativa conjunta com Itaipu sobre inovação e mercado." },
    { id: "colab-03", nome: "Formação Gestão de Resultados", desafio: "Colaborativa", descricao: "Capacitação para performance.", detalhes: "Treinamento com Cotrifred para gestão orientada a resultados." },
    { id: "colab-04", nome: "Ações do Dia C", desafio: "Colaborativa", descricao: "Mobilização social.", detalhes: "Ações voluntárias que reforçam princípios cooperativistas." },
    { id: "colab-05", nome: "Open Finance", desafio: "Colaborativa", descricao: "Integração financeira.", detalhes: "Permite maior controle e personalização financeira." },
    { id: "colab-06", nome: "Política de Governança", desafio: "Colaborativa", descricao: "Diretrizes para gestão.", detalhes: "Estabelece práticas de transparência e equidade." },
    { id: "colab-07", nome: "Guia de Boas Práticas", desafio: "Colaborativa", descricao: "Manual para gestão ética.", detalhes: "Orienta sobre práticas recomendadas de governança." },
    { id: "colab-08", nome: "Calendário Anual", desafio: "Colaborativa", descricao: "Planejamento estratégico.", detalhes: "Agenda organizada de eventos e reuniões." },
    { id: "colab-09", nome: "Portal SharePoint", desafio: "Colaborativa", descricao: "Repositório de conteúdos.", detalhes: "Centraliza documentos e informações relevantes." },
    { id: "colab-10", nome: "Small Farm Hub", desafio: "Colaborativa", descricao: "Hub para pequenas propriedades.", detalhes: "Tecnologias e suporte para pequenos produtores." },
    { id: "colab-11", nome: "FDR Inovação", desafio: "Colaborativa", descricao: "Fundo para projetos inovadores.", detalhes: "Fomento a iniciativas de empreendedorismo." },
    { id: "colab-12", nome: "Linha Sicredi Inova", desafio: "Colaborativa", descricao: "Crédito para tecnologia.", detalhes: "Apoio a projetos inovadores e modernização." },
    
    // Desenvolvimento de Capacidades
    { id: "cap-01", nome: "Castlight Desempenho", desafio: "Desenvolvimento de Capacidades", descricao: "Avaliação contínua de performance.", detalhes: "Acompanhamento estruturado via plataforma." },
    { id: "cap-02", nome: "Castlight Competências", desafio: "Desenvolvimento de Capacidades", descricao: "Feedback sobre competências.", detalhes: "Foco no desenvolvimento profissional." },
    { id: "cap-03", nome: "Ciclo de Objetivos", desafio: "Desenvolvimento de Capacidades", descricao: "Definição de metas estratégicas.", detalhes: "Conecta objetivos individuais à estratégia." },
    { id: "cap-04", nome: "Pauta do Gestor", desafio: "Desenvolvimento de Capacidades", descricao: "Monitoramento de metas.", detalhes: "Acompanhamento em reuniões de gestão." },
    { id: "cap-05", nome: "Política de Desempenho", desafio: "Desenvolvimento de Capacidades", descricao: "Diretrizes de avaliação.", detalhes: "Princípios para gestão de desempenho." },
    { id: "cap-06", nome: "Política de Educação", desafio: "Desenvolvimento de Capacidades", descricao: "Diretrizes de formação.", detalhes: "Orienta investimentos educacionais." },
    { id: "cap-07", nome: "Gestão das Ligas", desafio: "Desenvolvimento de Capacidades", descricao: "Grupos temáticos.", detalhes: "Modelo colaborativo de troca de conhecimento." },
    { id: "cap-08", nome: "Programa de Ideias", desafio: "Desenvolvimento de Capacidades", descricao: "Fomento à inovação.", detalhes: "Incentiva colaboradores a propor melhorias." },
    { id: "cap-09", nome: "Viagens Internacionais", desafio: "Desenvolvimento de Capacidades", descricao: "Experiências globais.", detalhes: "Networking e absorção de boas práticas." },
    { id: "cap-10", nome: "Inspirar", desafio: "Desenvolvimento de Capacidades", descricao: "Programa de engajamento.", detalhes: "Estimula evolução pessoal e profissional." },
    { id: "cap-11", nome: "Workshop Copilot", desafio: "Desenvolvimento de Capacidades", descricao: "Capacitação em IA.", detalhes: "Uso prático do Copilot no dia a dia." },
    { id: "cap-12", nome: "Dash BI", desafio: "Desenvolvimento de Capacidades", descricao: "Monitoramento de BI.", detalhes: "Incentivo à decisão baseada em dados." },
    { id: "cap-13", nome: "Módulo Gente que Evolui", desafio: "Desenvolvimento de Capacidades", descricao: "Conteúdo para evolução.", detalhes: "Foco em desenvolvimento contínuo." },
    { id: "cap-14", nome: "Trilha de Inovação", desafio: "Desenvolvimento de Capacidades", descricao: "Formação em inovação.", detalhes: "Conceitos e ferramentas para o futuro." },
    { id: "cap-15", nome: "Formação Copilot", desafio: "Desenvolvimento de Capacidades", descricao: "Uso avançado de IA.", detalhes: "Produtividade e integração tecnológica." },
    { id: "cap-16", nome: "South Summit", desafio: "Desenvolvimento de Capacidades", descricao: "Imersão em evento global.", detalhes: "Tendências e cultura de inovação." },
    { id: "cap-17", nome: "Cursos Sustentáveis", desafio: "Desenvolvimento de Capacidades", descricao: "Capacitação ESG.", detalhes: "Cursos alinhados aos objetivos estratégicos." },
    { id: "cap-18", nome: "Guia ESG Sistêmico", desafio: "Desenvolvimento de Capacidades", descricao: "Referência sustentável.", detalhes: "Orienta práticas ESG na cooperativa." },
    { id: "cap-19", nome: "Guia ESG Local", desafio: "Desenvolvimento de Capacidades", descricao: "Diretrizes locais.", detalhes: "Boas práticas adaptadas à realidade local." },
    
    // ESG
    { id: "esg-01", nome: "RenovaEco Solar", desafio: "ESG", descricao: "Energia limpa.", detalhes: "Implantação de energia solar nas unidades." },
    { id: "esg-02", nome: "Gás Ecológico", desafio: "ESG", descricao: "Climatização sustentável.", detalhes: "Substituição por gases menos nocivos." },
    { id: "esg-03", nome: "Neutralização Emissões", desafio: "ESG", descricao: "Compensação de carbono.", detalhes: "Projetos para neutralizar gases de efeito estufa." },
    { id: "esg-04", nome: "Pacto Global ONU", desafio: "ESG", descricao: "Iniciativa global.", detalhes: "Adesão aos ODS e práticas responsáveis." },
    { id: "esg-05", nome: "Relatório Sustentabilidade", desafio: "ESG", descricao: "Transparência ESG.", detalhes: "Apresentação de resultados sustentáveis." },
    { id: "esg-06", nome: "Frameworks Globais", desafio: "ESG", descricao: "Estratégia internacional.", detalhes: "Alinhamento a padrões globais de ESG." },
    { id: "esg-07", nome: "Propriedade Sustentável", desafio: "ESG", descricao: "Sustentabilidade no campo.", detalhes: "Incentivo a práticas rurais responsáveis." },
    { id: "esg-08", nome: "ASA Agro", desafio: "ESG", descricao: "Ambiente saudável.", detalhes: "Boas práticas ambientais no agro." },
    { id: "esg-09", nome: "GERE Agro", desafio: "ESG", descricao: "Gestão sustentável.", detalhes: "Foco em resultados e sustentabilidade." },
    { id: "esg-10", nome: "Agro em Foco", desafio: "ESG", descricao: "Capacitação agro.", detalhes: "Inovação e sustentabilidade no setor." },
    { id: "esg-11", nome: "Empresa Rural", desafio: "ESG", descricao: "Gestão eficiente.", detalhes: "Competências para gestão rural." },
    { id: "esg-12", nome: "Dia C", desafio: "ESG", descricao: "Voluntariado.", detalhes: "Ações sociais nas comunidades." },
    { id: "esg-13", nome: "Projeto PISA", desafio: "ESG", descricao: "Produção integrada.", detalhes: "Práticas sustentáveis na agropecuária." },
    { id: "esg-14", nome: "Educação Ambiental", desafio: "ESG", descricao: "Trilhas formativas.", detalhes: "Cursos sobre preservação ambiental." },
    { id: "esg-15", nome: "Quadro Feminino", desafio: "ESG", descricao: "Diversidade de gênero.", detalhes: "Presença significativa de mulheres." },
    { id: "esg-16", nome: "Liderança Feminina", desafio: "ESG", descricao: "Mulheres na liderança.", detalhes: "Equidade em cargos de gestão." },
    { id: "esg-17", nome: "Código de Conduta", desafio: "ESG", descricao: "Diretrizes éticas.", detalhes: "Princípios de integridade e responsabilidade." },
    { id: "esg-18", nome: "Canal de Denúncias", desafio: "ESG", descricao: "Reporte seguro.", detalhes: "Canal confidencial para denúncias." },
    { id: "esg-19", nome: "Formação Inclusão", desafio: "ESG", descricao: "Capacitação em diversidade.", detalhes: "Treinamento sobre respeito e inclusão." },
    { id: "esg-20", nome: "SIPAT Inclusiva", desafio: "ESG", descricao: "Conscientização.", detalhes: "Ações em eventos internos." },
    { id: "esg-21", nome: "Comitê Diversidade", desafio: "ESG", descricao: "Grupo estratégico.", detalhes: "Promove políticas de inclusão." },
    { id: "esg-22", nome: "Consultoria DE&I", desafio: "ESG", descricao: "Apoio técnico.", detalhes: "Orientação especializada em diversidade." },
    { id: "esg-23", nome: "Censo Diversidade", desafio: "ESG", descricao: "Mapeamento interno.", detalhes: "Dados para embasar ações inclusivas." },
    { id: "esg-24", nome: "Regulamento Comitê", desafio: "ESG", descricao: "Normas de atuação.", detalhes: "Diretrizes para o comitê de diversidade." },
    { id: "esg-25", nome: "Dia da Família", desafio: "ESG", descricao: "Integração social.", detalhes: "Fortalecimento de vínculos familiares." },
    { id: "esg-26", nome: "Riscos Operacionais", desafio: "ESG", descricao: "Gestão de riscos.", detalhes: "Mitigação e controles internos." },
    { id: "esg-27", nome: "Plano de Riscos", desafio: "ESG", descricao: "Planejamento.", detalhes: "Estratégias para gerenciamento de riscos." },
    { id: "esg-28", nome: "Ética e Conduta", desafio: "ESG", descricao: "Princípios éticos.", detalhes: "Orienta condutas e integridade." },
    { id: "esg-29", nome: "Norma Consequências", desafio: "ESG", descricao: "Sanções disciplinares.", detalhes: "Regras para descumprimento de condutas." },
    { id: "esg-30", nome: "Cyber Segurança", desafio: "ESG", descricao: "Proteção digital.", detalhes: "Segurança contra ameaças cibernéticas." },
    { id: "esg-31", nome: "Política Ciber", desafio: "ESG", descricao: "Diretrizes de proteção.", detalhes: "Segurança da informação." },
    { id: "esg-32", nome: "Inventário Sistemas", desafio: "ESG", descricao: "Controle de ativos.", detalhes: "Gestão de sistemas tecnológicos." },
    { id: "esg-33", nome: "BI Controles", desafio: "ESG", descricao: "Monitoramento.", detalhes: "Dashboard de controles críticos." },
    { id: "esg-34", nome: "Divulgação Balanços", desafio: "ESG", descricao: "Transparência.", detalhes: "Publicação de demonstrações financeiras." },
    { id: "esg-35", nome: "Norma Compras", desafio: "ESG", descricao: "Aquisições responsáveis.", detalhes: "Diretrizes para contratação." },
    { id: "esg-36", nome: "Ligas Táticas", desafio: "ESG", descricao: "Execução estratégica.", detalhes: "Grupos para implementação de projetos." },
    { id: "esg-37", nome: "PDLE", desafio: "ESG", descricao: "Liderança.", detalhes: "Desenvolvimento de gestores." },
    { id: "esg-38", nome: "Seleção Desenvolve", desafio: "ESG", descricao: "Recrutamento.", detalhes: "Foco em desenvolvimento contínuo." },
    { id: "esg-39", nome: "Fortalecer", desafio: "ESG", descricao: "Cultura interna.", detalhes: "Engajamento e evolução das equipes." },
    
    // Finanças Verdes
    { id: "fin-01", nome: "RENOVAGRO", desafio: "Finanças Verdes", descricao: "Sustentabilidade agro.", detalhes: "Financiamento de energias renováveis." },
    { id: "fin-02", nome: "INOVAGRO", desafio: "Finanças Verdes", descricao: "Inovação agro.", detalhes: "Investimento em tecnologia no campo." },
    { id: "fin-03", nome: "PRONAF Bioeconomia", desafio: "Finanças Verdes", descricao: "Agroecologia.", detalhes: "Crédito para produção sustentável." },
    { id: "fin-04", nome: "Manual Mulher", desafio: "Finanças Verdes", descricao: "Inclusão feminina.", detalhes: "Orientação para mulheres no agro." },
    { id: "fin-05", nome: "BNDES Clima", desafio: "Finanças Verdes", descricao: "Mitigação climática.", detalhes: "Projetos de redução de emissões." },
    { id: "fin-06", nome: "Pronaf Mulher Agro", desafio: "Finanças Verdes", descricao: "Mulheres rurais.", detalhes: "Fomento à agroecologia feminina." },
    { id: "fin-07", nome: "Fundo Clima", desafio: "Finanças Verdes", descricao: "Projetos ambientais.", detalhes: "Financiamento para sustentabilidade." }
];

/* =========================================
   LÓGICA DO MODAL
   ========================================= */
function openModal(projectId) {
    const project = projectsData.find(p => p.id === projectId);
    if (!project) return;
    
    document.getElementById('modal-title').textContent = project.nome;
    document.getElementById('modal-description').textContent = project.descricao;
    document.getElementById('modal-full-details').textContent = project.detalhes;
    
    document.getElementById('project-modal').classList.remove('hidden');
}

function closeModal() {
    document.getElementById('project-modal').classList.add('hidden');
}

/* =========================================
   RENDERIZAÇÃO DE PROJETOS
   ========================================= */
function renderProjects(projects, container) {
    if (projects.length === 0) {
        container.innerHTML = '<p style="color: #9ca3af; font-style: italic; padding: 1rem; text-align: center; grid-column: 1/-1;">Nenhum projeto encontrado.</p>';
        return;
    }
    
    container.innerHTML = projects.map(p => `
        <div class="project-card">
            <h4>${p.nome}</h4>
            <p>${p.descricao}</p>
            <button onclick="openModal('${p.id}')" class="btn-details">Ver detalhes</button>
        </div>
    `).join('');
}

function filterProjects(searchTerm, dimensionName) {
    const containers = document.querySelectorAll('.projects-container');
    let targetContainer = null;
    
    // Encontra o container correto da dimensão atual
    containers.forEach(c => {
        if (c.getAttribute('data-dimension') === dimensionName) targetContainer = c;
    });
    
    if (!targetContainer) return;
    
    const term = searchTerm.toLowerCase();
    const filtered = projectsData.filter(p => 
        p.desafio === dimensionName && 
        (p.nome.toLowerCase().includes(term) || p.descricao.toLowerCase().includes(term))
    );
    
    renderProjects(filtered, targetContainer);
}

/* =========================================
   NAVEGAÇÃO (TROCA DE CONTEÚDO)
   ========================================= */
function switchContent(contentId) {
    // 1. Esconde todas as seções principais
    document.querySelectorAll('.content-section').forEach(section => {
        section.classList.add('hidden');
    });

    // 2. Mostra a seção desejada
    const activeSection = document.getElementById(`content-${contentId}`);
    if (activeSection) {
        activeSection.classList.remove('hidden');
        // Rola suavemente para o topo
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
}

function switchInnerTab(dimensionPrefix, tabName, event) {
    const container = document.getElementById(`content-dimensao-${dimensionPrefix}`);
    if (!container) return;
    
    // 1. Esconde todas as abas internas dessa dimensão
    container.querySelectorAll('.inner-tab-content').forEach(c => c.classList.add('hidden'));
    
    // 2. Remove a classe 'active' de todos os botões dessa dimensão
    container.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    
    // 3. Mostra o conteúdo da aba clicada
    const target = document.getElementById(`${dimensionPrefix}-${tabName}`);
    if (target) target.classList.remove('hidden');
    
    // 4. Adiciona a classe 'active' ao botão clicado
    if (event && event.target) event.target.classList.add('active');
}

/* =========================================
   INICIALIZAÇÃO (ON LOAD)
   ========================================= */
window.onload = function() {
    // Renderiza a lista de projetos em todas as dimensões
    document.querySelectorAll('.projects-container').forEach(container => {
        const dimName = container.getAttribute('data-dimension');
        renderProjects(projectsData.filter(p => p.desafio === dimName), container);
    });
    
    // Garante que a página comece na Introdução
    switchContent('intro');
};